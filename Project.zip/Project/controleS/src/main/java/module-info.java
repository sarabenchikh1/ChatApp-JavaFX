module com.example.controles {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.controles to javafx.fxml;
    exports com.example.controles;
}